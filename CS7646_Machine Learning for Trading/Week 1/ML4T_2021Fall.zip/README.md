# Copyright 2020, Georgia Tech Research Corporation    
# Atlanta, Georgia 30332-0415     
# All Rights Reserved  

# ML4T_2020 Summer 
Course website: http://lucylabs.gatech.edu/ml4t/

Information on using the autograder on buffet0x servers: http://lucylabs.gatech.edu/ml4t/ml4t-software-setup/


